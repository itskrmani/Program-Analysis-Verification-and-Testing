**Dependencies**

```bash
pip install antlr4-python3-runtime==4.7.2
pip install networkx
sudo apt-get install python3-tk 
```

**Running an example**

  ```bash
  ./kachua.py ./example/test.tl
  ```
  
**AST Nodes**

- Please refere `ast/kachuaAST.py`
