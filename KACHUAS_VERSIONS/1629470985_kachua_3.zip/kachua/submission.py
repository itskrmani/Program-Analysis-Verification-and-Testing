
import sys
sys.path.insert(0, './ast')

import kachuaAST

def genCFG(ir):
    # your code here
    cfg = None
    return cfg

def dumpCFG(cfg):
    # dump CFG to a dot file
    pass
